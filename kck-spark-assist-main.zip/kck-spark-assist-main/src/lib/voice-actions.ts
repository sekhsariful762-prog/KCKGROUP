export type VoiceCommandResult = {
  reply: string;
  action?: string;
  url?: string;
  internalPath?: string;
};

export const SITE_SHORTCUTS: { keys: string[]; url: string; name: string }[] = [
  { name: "YouTube", keys: ["youtube", "you tube", "youtube app"], url: "https://www.youtube.com" },
  { name: "Google", keys: ["google"], url: "https://www.google.com" },
  { name: "Gmail", keys: ["gmail", "mail"], url: "https://mail.google.com" },
  { name: "Google Maps", keys: ["maps", "google maps"], url: "https://maps.google.com" },
  { name: "Facebook", keys: ["facebook", "fb"], url: "https://www.facebook.com" },
  { name: "Instagram", keys: ["instagram", "insta"], url: "https://www.instagram.com" },
  { name: "X (Twitter)", keys: ["twitter", "x.com", "x"], url: "https://x.com" },
  { name: "LinkedIn", keys: ["linkedin"], url: "https://www.linkedin.com" },
  { name: "WhatsApp", keys: ["whatsapp", "whats app"], url: "https://web.whatsapp.com" },
  { name: "GitHub", keys: ["github", "git hub"], url: "https://github.com" },
];

function normalizeCommand(text: string) {
  return text.trim().toLowerCase().replace(/[؟?!.،]+$/g, "").replace(/\s+/g, " ");
}

function cleanTarget(target: string) {
  return target
    .replace(/\b(app|application|website|site|web)\b/g, "")
    .replace(/\b(please|plz|pls|zara|jara|bhai)\b/g, "")
    .trim();
}

function resolveShortcut(target: string) {
  const cleaned = cleanTarget(target);
  return SITE_SHORTCUTS.find((site) => site.keys.some((key) => cleaned === key || cleaned.includes(key)));
}

function externalUrlFor(target: string) {
  const cleaned = cleanTarget(target).replace(/\s+/g, "");
  if (!cleaned) return null;
  const url = cleaned.startsWith("http") ? cleaned : `https://${cleaned}`;
  try {
    const parsed = new URL(url);
    return parsed.hostname.includes(".") ? parsed.toString() : null;
  } catch {
    return null;
  }
}

export function resolveVoiceCommand(text: string): VoiceCommandResult | null {
  const t = normalizeCommand(text);
  if (!t) return null;

  const openPatterns = [
    /^(?:open|launch|go to|visit|start|run|kholo|khol|khul|chalao|chalayo|open karo)\s+(.+)$/,
    /^(.+?)\s+(?:open|kholo|khol|khul|chalao|chalayo|open karo|karo)$/,
  ];

  for (const pattern of openPatterns) {
    const match = t.match(pattern);
    if (!match) continue;
    const target = cleanTarget(match[1]);
    if (/^chat$|^kck chat$/.test(target)) return { reply: "Opening chat.", internalPath: "/chat", action: "open:/chat" };
    if (/^voice$|^kck voice$/.test(target)) return { reply: "Opening voice assistant.", internalPath: "/voice", action: "open:/voice" };

    const shortcut = resolveShortcut(target);
    if (shortcut) return { reply: `Opening ${shortcut.name}.`, url: shortcut.url, action: `open:${shortcut.url}` };

    const url = externalUrlFor(target);
    if (url) return { reply: `Opening ${url}.`, url, action: `open:${url}` };
  }

  const yt = t.match(/^search\s+youtube\s+(?:for\s+)?(.+)$/) || t.match(/^youtube\s+(?:search\s+)?(.+)$/);
  if (yt) {
    const q = yt[1].trim();
    return { reply: `Searching YouTube for ${q}.`, url: `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`, action: `youtube:${q}` };
  }

  const wiki = t.match(/^(?:search\s+)?wikipedia\s+(?:for\s+)?(.+)$/);
  if (wiki) {
    const q = wiki[1].trim();
    return { reply: `Searching Wikipedia for ${q}.`, url: `https://en.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(q)}`, action: `wiki:${q}` };
  }

  const img = t.match(/^(?:search\s+)?images?\s+(?:of|for)\s+(.+)$/);
  if (img) {
    const q = img[1].trim();
    return { reply: `Image search for ${q}.`, url: `https://www.google.com/search?tbm=isch&q=${encodeURIComponent(q)}`, action: `images:${q}` };
  }

  const news = t.match(/^(?:search\s+)?news\s+(?:about\s+|for\s+)?(.+)$/);
  if (news) {
    const q = news[1].trim();
    return { reply: `News search for ${q}.`, url: `https://news.google.com/search?q=${encodeURIComponent(q)}`, action: `news:${q}` };
  }

  const google = t.match(/^(?:search(?:\s+google)?|google)\s+(?:for\s+)?(.+)$/);
  if (google) {
    const q = google[1].trim();
    return { reply: `Searching Google for ${q}.`, url: `https://www.google.com/search?q=${encodeURIComponent(q)}`, action: `google:${q}` };
  }

  if (/^what(?:'s| is)?\s+the\s+time/.test(t) || t === "time") {
    return { reply: `It is ${new Date().toLocaleTimeString()}.` };
  }

  if (/^what(?:'s| is)?\s+(?:the\s+)?date/.test(t) || t === "date") {
    return {
      reply: `Today is ${new Date().toLocaleDateString(undefined, {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      })}.`,
    };
  }

  return null;
}

export function executeVoiceCommand(command: VoiceCommandResult, newTab = false) {
  if (command.internalPath) {
    window.location.assign(command.internalPath);
    return true;
  }

  if (!command.url) return false;

  if (newTab) {
    const opened = window.open(command.url, "_blank", "noopener,noreferrer");
    if (opened) return true;
  }

  window.location.assign(command.url);
  return true;
}