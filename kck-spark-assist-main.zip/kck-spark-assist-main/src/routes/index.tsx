import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, MessageSquare, Code, Languages, Mic, Zap } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "KCK AI Assistant — Chat, write, code, translate" },
      { name: "description", content: "All-in-one AI assistant powered by frontier models. Chat, brainstorm, code, translate, and get things done." },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: MessageSquare, title: "Smart Chat", desc: "Natural conversations with memory across threads." },
  { icon: Code, title: "Coding Help", desc: "Generate, refactor, and debug code in any language." },
  { icon: Languages, title: "Translation", desc: "Instant translation between 100+ languages." },
  { icon: Mic, title: "Voice Input", desc: "Talk to the assistant hands-free." },
  { icon: Sparkles, title: "Content Creation", desc: "Drafts, emails, posts, summaries — in seconds." },
  { icon: Zap, title: "Productivity", desc: "Notes, tasks, and quick answers in one place." },
];

function Landing() {
  const { user, loading } = useAuth();
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-accent/20">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/20 ring-1 ring-primary/40">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <span className="text-lg font-semibold">KCK AI</span>
        </div>
        <nav className="flex items-center gap-3">
          {!loading && (user ? (
            <Link to="/chat" className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
              Open chat
            </Link>
          ) : (
            <>
              <Link to="/login" className="text-sm text-muted-foreground hover:text-foreground">Sign in</Link>
              <Link to="/signup" className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
                Get started
              </Link>
            </>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-6 pb-24 pt-12">
        <section className="text-center">
          <div className="mx-auto inline-flex items-center gap-2 rounded-full border bg-card/50 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Powered by frontier AI models
          </div>
          <h1 className="mt-6 text-balance text-5xl font-bold tracking-tight sm:text-6xl">
            Your all-in-one <span className="bg-gradient-to-r from-primary to-pink-400 bg-clip-text text-transparent">AI Assistant</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-pretty text-lg text-muted-foreground">
            Chat, write, code, translate, and stay productive — all in one place. Built for speed, designed for clarity.
          </p>
          <div className="mt-8 flex justify-center gap-3">
            <Link to={user ? "/chat" : "/signup"} className="rounded-lg bg-primary px-6 py-3 text-base font-medium text-primary-foreground hover:opacity-90">
              {user ? "Open chat" : "Start free"}
            </Link>
            <Link to="/login" className="rounded-lg border px-6 py-3 text-base hover:bg-accent">
              Sign in
            </Link>
          </div>
        </section>

        <section className="mt-24 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl border bg-card/50 p-5 backdrop-blur">
              <f.icon className="h-6 w-6 text-primary" />
              <h3 className="mt-3 font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}
