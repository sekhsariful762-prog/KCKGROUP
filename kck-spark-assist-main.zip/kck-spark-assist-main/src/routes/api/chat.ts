import { createFileRoute } from "@tanstack/react-router";
import { createFileRoute as _ } from "@tanstack/react-router";

// Edge route: proxies streaming chat completions from Lovable AI Gateway.
// Verifies the Supabase bearer token before forwarding.

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authHeader = request.headers.get("authorization") || "";
        const token = authHeader.replace(/^Bearer\s+/i, "").trim();
        if (!token) return new Response("Unauthorized", { status: 401 });

        // Verify token against Supabase
        const supaUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
        const supaKey =
          process.env.SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
        if (!supaUrl || !supaKey) return new Response("Server misconfigured", { status: 500 });

        const verify = await fetch(`${supaUrl}/auth/v1/user`, {
          headers: { Authorization: `Bearer ${token}`, apikey: supaKey },
        });
        if (!verify.ok) return new Response("Unauthorized", { status: 401 });

        const body = await request.json().catch(() => null) as
          | { messages?: Array<{ role: string; content: string }>; model?: string }
          | null;
        if (!body?.messages?.length) return new Response("Bad request", { status: 400 });

        const apiKey = process.env.LOVABLE_API_KEY;
        if (!apiKey) return new Response("AI gateway not configured", { status: 500 });

        const systemPrompt =
          "You are KCK AI Assistant, a helpful, friendly, and concise all-in-one assistant. " +
          "Use markdown when it improves clarity (code blocks for code, lists for steps). " +
          "Keep answers focused and accurate.";

        const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: body.model || "google/gemini-3-flash-preview",
            messages: [{ role: "system", content: systemPrompt }, ...body.messages],
            stream: true,
          }),
        });

        if (!upstream.ok) {
          if (upstream.status === 429)
            return new Response(JSON.stringify({ error: "Rate limit exceeded. Please slow down." }), {
              status: 429,
              headers: { "Content-Type": "application/json" },
            });
          if (upstream.status === 402)
            return new Response(
              JSON.stringify({ error: "AI credits exhausted. Please top up your workspace." }),
              { status: 402, headers: { "Content-Type": "application/json" } },
            );
          const t = await upstream.text();
          console.error("AI gateway error", upstream.status, t);
          return new Response(JSON.stringify({ error: "AI gateway error" }), {
            status: 500,
            headers: { "Content-Type": "application/json" },
          });
        }

        return new Response(upstream.body, {
          headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache" },
        });
      },
    },
  },
});

// silence unused
void _;
