import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Plus, Send, Sparkles, Trash2, LogOut, MessageSquare, Mic, Square } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { executeVoiceCommand, resolveVoiceCommand } from "@/lib/voice-actions";

type Msg = { role: "user" | "assistant"; content: string };
type Conversation = { id: string; title: string; updated_at: string };

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({ meta: [{ title: "Chat — KCK AI" }] }),
  validateSearch: (s: Record<string, unknown>) => ({ c: typeof s.c === "string" ? s.c : undefined }),
  component: ChatPage,
});

function ChatPage() {
  const { user, signOut } = useAuth();
  const { c: convId } = useSearch({ from: "/_authenticated/chat" });
  const navigate = useNavigate();
  const qc = useQueryClient();

  // Sidebar: list conversations
  const conversationsQ = useQuery({
    queryKey: ["conversations"],
    queryFn: async (): Promise<Conversation[]> => {
      const { data, error } = await supabase
        .from("conversations")
        .select("id,title,updated_at")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return data as Conversation[];
    },
  });

  // Messages for selected
  const messagesQ = useQuery({
    queryKey: ["messages", convId],
    queryFn: async (): Promise<Msg[]> => {
      if (!convId) return [];
      const { data, error } = await supabase
        .from("messages")
        .select("role,content")
        .eq("conversation_id", convId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data as Msg[]).filter((m) => m.role === "user" || m.role === "assistant");
    },
    enabled: !!convId,
  });

  const [pendingMessages, setPendingMessages] = useState<Msg[] | null>(null);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const messages = pendingMessages ?? messagesQ.data ?? [];

  useEffect(() => {
    setPendingMessages(null);
  }, [convId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function ensureConversation(firstMessage: string): Promise<string> {
    if (convId) return convId;
    const title = firstMessage.slice(0, 60);
    const { data, error } = await supabase
      .from("conversations")
      .insert({ user_id: user!.id, title })
      .select("id")
      .single();
    if (error) throw error;
    qc.invalidateQueries({ queryKey: ["conversations"] });
    navigate({ to: "/chat", search: { c: data.id }, replace: true });
    return data.id;
  }

  async function sendMessage(text: string) {
    if (!text.trim() || streaming) return;
    const command = resolveVoiceCommand(text);
    if (command) {
      toast.message(command.reply);
      executeVoiceCommand(command);
      setInput("");
      return;
    }
    setInput("");
    setStreaming(true);

    const userMsg: Msg = { role: "user", content: text };
    const history = [...messages, userMsg];
    setPendingMessages([...history, { role: "assistant", content: "" }]);

    try {
      const cid = await ensureConversation(text);
      // persist user message
      await supabase.from("messages").insert({
        conversation_id: cid,
        user_id: user!.id,
        role: "user",
        content: text,
      });

      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      const ctrl = new AbortController();
      abortRef.current = ctrl;

      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ messages: history }),
        signal: ctrl.signal,
      });

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: "Request failed" }));
        throw new Error(err.error || `HTTP ${resp.status}`);
      }
      if (!resp.body) throw new Error("No response body");

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      let assistant = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let idx: number;
        while ((idx = buf.indexOf("\n")) !== -1) {
          let line = buf.slice(0, idx);
          buf = buf.slice(idx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line || line.startsWith(":") || !line.startsWith("data: ")) continue;
          const json = line.slice(6).trim();
          if (json === "[DONE]") { buf = ""; break; }
          try {
            const parsed = JSON.parse(json);
            const delta = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (delta) {
              assistant += delta;
              setPendingMessages([...history, { role: "assistant", content: assistant }]);
            }
          } catch {
            buf = line + "\n" + buf;
            break;
          }
        }
      }

      if (assistant) {
        await supabase.from("messages").insert({
          conversation_id: cid,
          user_id: user!.id,
          role: "assistant",
          content: assistant,
        });
        await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", cid);
        qc.invalidateQueries({ queryKey: ["conversations"] });
        qc.invalidateQueries({ queryKey: ["messages", cid] });
      }
      setPendingMessages(null);
    } catch (e: unknown) {
      const err = e as { name?: string; message?: string };
      if (err.name === "AbortError") {
        toast.message("Stopped.");
      } else {
        toast.error(err.message || "Something went wrong");
      }
      setPendingMessages(null);
    } finally {
      setStreaming(false);
      abortRef.current = null;
    }
  }

  function stop() {
    abortRef.current?.abort();
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    sendMessage(input);
  }

  function onKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  }

  function handleVoiceTranscript(text: string) {
    const command = resolveVoiceCommand(text);
    if (command) {
      toast.message(command.reply);
      executeVoiceCommand(command);
      return;
    }
    setInput((v) => (v ? `${v} ${text}` : text));
  }

  async function newChat() {
    navigate({ to: "/chat", search: { c: undefined }, replace: false });
    setPendingMessages(null);
  }

  async function deleteConversation(id: string) {
    if (!confirm("Delete this conversation?")) return;
    await supabase.from("conversations").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["conversations"] });
    if (convId === id) navigate({ to: "/chat", search: { c: undefined } });
  }

  const suggestions = [
    "Write a friendly cold email to a potential client",
    "Explain async/await in JavaScript with examples",
    "Translate this to Spanish: 'Have a wonderful day'",
    "Summarize the key ideas of stoicism in 5 bullets",
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      {/* Sidebar */}
      <aside className="hidden w-72 flex-col border-r bg-sidebar text-sidebar-foreground md:flex">
        <div className="flex items-center gap-2 px-4 py-4">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          <span className="font-semibold">KCK AI</span>
        </div>
        <div className="px-3">
          <Button onClick={newChat} className="w-full justify-start gap-2">
            <Plus className="h-4 w-4" /> New chat
          </Button>
          <Link to="/voice" className="mt-2 flex w-full items-center justify-start gap-2 rounded-md border px-3 py-2 text-sm hover:bg-sidebar-accent">
            <Mic className="h-4 w-4" /> Voice assistant
          </Link>
        </div>
        <div className="mt-4 flex-1 overflow-y-auto px-2">
          {conversationsQ.data?.length === 0 && (
            <p className="px-3 py-2 text-xs text-muted-foreground">No chats yet.</p>
          )}
          {conversationsQ.data?.map((c) => (
            <div
              key={c.id}
              className={cn(
                "group flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-sidebar-accent",
                convId === c.id && "bg-sidebar-accent",
              )}
              onClick={() => navigate({ to: "/chat", search: { c: c.id } })}
            >
              <MessageSquare className="h-4 w-4 shrink-0 opacity-60" />
              <span className="flex-1 truncate">{c.title}</span>
              <button
                onClick={(e) => { e.stopPropagation(); deleteConversation(c.id); }}
                className="opacity-0 group-hover:opacity-100"
                aria-label="Delete"
              >
                <Trash2 className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
              </button>
            </div>
          ))}
        </div>
        <div className="border-t p-3">
          <div className="flex items-center gap-3 px-2 py-1">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 text-sm font-medium">
              {(user?.email || "?")[0].toUpperCase()}
            </div>
            <div className="flex-1 truncate text-xs text-muted-foreground">{user?.email}</div>
            <button onClick={signOut} aria-label="Sign out" className="rounded p-1 hover:bg-sidebar-accent">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex flex-1 flex-col">
        <header className="flex items-center justify-between border-b px-4 py-3 md:hidden">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="font-semibold">KCK AI</span>
          </div>
          <Button size="sm" variant="ghost" onClick={newChat}><Plus className="h-4 w-4" /></Button>
        </header>

        <div ref={scrollRef} className="flex-1 overflow-y-auto">
          {messages.length === 0 ? (
            <div className="mx-auto flex h-full max-w-2xl flex-col items-center justify-center px-6 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/20 ring-1 ring-primary/40">
                <Sparkles className="h-7 w-7 text-primary" />
              </div>
              <h1 className="mt-4 text-2xl font-semibold">How can I help you today?</h1>
              <p className="mt-1 text-sm text-muted-foreground">Ask anything. I can write, code, translate, and more.</p>
              <div className="mt-8 grid w-full gap-2 sm:grid-cols-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => sendMessage(s)}
                    className="rounded-xl border bg-card/50 p-3 text-left text-sm hover:bg-accent"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="mx-auto max-w-3xl px-4 py-6">
              {messages.map((m, i) => (
                <MessageBubble key={i} msg={m} />
              ))}
              {streaming && messages[messages.length - 1]?.role === "assistant" && messages[messages.length - 1].content === "" && (
                <div className="flex gap-2 px-12 text-sm text-muted-foreground">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
                  Thinking…
                </div>
              )}
            </div>
          )}
        </div>

        <div className="border-t bg-background p-4">
          <form onSubmit={onSubmit} className="mx-auto flex max-w-3xl items-end gap-2">
            <div className="flex flex-1 items-end rounded-2xl border bg-card px-3 py-2 shadow-sm focus-within:ring-2 focus-within:ring-ring">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={onKey}
                placeholder="Message KCK AI…"
                rows={1}
                className="max-h-48 min-h-[24px] flex-1 resize-none border-0 bg-transparent px-1 py-1 shadow-none focus-visible:ring-0"
              />
              <VoiceButton onTranscript={handleVoiceTranscript} />
            </div>
            {streaming ? (
              <Button type="button" onClick={stop} variant="secondary" size="icon" className="h-11 w-11">
                <Square className="h-4 w-4" />
              </Button>
            ) : (
              <Button type="submit" size="icon" disabled={!input.trim()} className="h-11 w-11">
                <Send className="h-4 w-4" />
              </Button>
            )}
          </form>
          <p className="mx-auto mt-2 max-w-3xl text-center text-xs text-muted-foreground">
            AI can make mistakes. Verify important info.
          </p>
        </div>
      </main>
    </div>
  );
}

function MessageBubble({ msg }: { msg: Msg }) {
  const isUser = msg.role === "user";
  return (
    <div className={cn("mb-6 flex gap-3", isUser && "flex-row-reverse")}>
      <div
        className={cn(
          "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-medium",
          isUser ? "bg-primary text-primary-foreground" : "bg-accent text-accent-foreground",
        )}
      >
        {isUser ? "You" : <Sparkles className="h-4 w-4" />}
      </div>
      <div
        className={cn(
          "prose-chat max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
          isUser ? "bg-primary/15 text-foreground" : "bg-card",
        )}
      >
        {isUser ? (
          <div className="whitespace-pre-wrap">{msg.content}</div>
        ) : (
          <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content || "…"}</ReactMarkdown>
        )}
      </div>
    </div>
  );
}

function VoiceButton({ onTranscript }: { onTranscript: (t: string) => void }) {
  const [recording, setRecording] = useState(false);
  const recRef = useRef<unknown>(null);

  async function toggle() {
    const w = window as unknown as {
      SpeechRecognition?: new () => unknown;
      webkitSpeechRecognition?: new () => unknown;
    };
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) {
      toast.error("Voice input is not supported in this browser. Try Chrome or Edge.");
      return;
    }
    if (!window.isSecureContext) {
      toast.error("Voice input requires HTTPS.");
      return;
    }
    if (recording) {
      (recRef.current as { stop: () => void } | null)?.stop();
      setRecording(false);
      return;
    }

    // Request microphone permission immediately from the click gesture so the browser prompt appears reliably.
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        toast.error("Microphone access is not supported in this browser.");
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // We only needed the permission prompt; SpeechRecognition opens its own stream.
      stream.getTracks().forEach((t) => t.stop());
    } catch (err) {
      const e = err as { name?: string };
      if (e.name === "NotAllowedError") {
        toast.error("Microphone permission denied. Allow it in your browser settings.");
      } else if (e.name === "NotFoundError") {
        toast.error("No microphone found on this device.");
      } else if (e.name === "NotReadableError") {
        toast.error("Microphone is in use by another app.");
      } else {
        toast.error("Could not access microphone.");
      }
      return;
    }

    const rec = new SR() as {
      lang: string;
      interimResults: boolean;
      continuous: boolean;
      onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
      onerror: (e: { error?: string }) => void;
      onend: () => void;
      start: () => void;
      stop: () => void;
    };
    rec.lang = "en-US";
    rec.interimResults = false;
    rec.continuous = false;
    rec.onresult = (e) => {
      const last = e.results[e.results.length - 1];
      const text = last[0].transcript;
      onTranscript(text);
    };
    rec.onerror = (e) => {
      if (e?.error === "not-allowed" || e?.error === "service-not-allowed") {
        toast.error("Microphone permission denied.");
      } else if (e?.error === "no-speech") {
        toast.message("No speech detected.");
      } else if (e?.error) {
        toast.error(`Voice error: ${e.error}`);
      }
      setRecording(false);
    };
    rec.onend = () => setRecording(false);
    try {
      rec.start();
      recRef.current = rec;
      setRecording(true);
      toast.message("Listening…");
    } catch {
      toast.error("Could not start voice input.");
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      className={cn(
        "ml-1 rounded-lg p-2 text-muted-foreground hover:text-foreground",
        recording && "text-destructive",
      )}
      aria-label="Voice input"
    >
      <Mic className="h-4 w-4" />
    </button>
  );
}
