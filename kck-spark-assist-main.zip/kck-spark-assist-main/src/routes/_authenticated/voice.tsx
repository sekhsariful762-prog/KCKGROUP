import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Mic, MicOff, Volume2, VolumeX, Sparkles, Settings, MessageSquare, History, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { executeVoiceCommand, resolveVoiceCommand, SITE_SHORTCUTS } from "@/lib/voice-actions";

export const Route = createFileRoute("/_authenticated/voice")({
  head: () => ({ meta: [{ title: "Voice — KCK AI" }] }),
  component: VoicePage,
});

type LogEntry = { id: string; ts: number; user: string; reply: string; action?: string };
type Settings = {
  lang: string;
  wakeWord: boolean;
  continuous: boolean;
  voiceURI: string | null;
  rate: number;
  pitch: number;
  tts: boolean;
};

const LANGS = [
  { code: "en-US", label: "English (US)" },
  { code: "en-IN", label: "English (India)" },
  { code: "hi-IN", label: "हिन्दी (Hindi)" },
  { code: "ur-PK", label: "اردو (Urdu)" },
  { code: "bn-IN", label: "বাংলা (Bengali)" },
];

const DEFAULT_SETTINGS: Settings = {
  lang: "en-US",
  wakeWord: false,
  continuous: false,
  voiceURI: null,
  rate: 1,
  pitch: 1,
  tts: true,
};

function VoicePage() {
  const { user, signOut } = useAuth();
  const [settings, setSettings] = useState<Settings>(() => {
    if (typeof window === "undefined") return DEFAULT_SETTINGS;
    try {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem("kck.voice.settings") || "{}") };
    } catch {
      return DEFAULT_SETTINGS;
    }
  });
  const [log, setLog] = useState<LogEntry[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(localStorage.getItem("kck.voice.log") || "[]"); } catch { return []; }
  });
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [showSettings, setShowSettings] = useState(false);

  const recRef = useRef<any>(null);
  const restartRef = useRef(false);

  useEffect(() => {
    localStorage.setItem("kck.voice.settings", JSON.stringify(settings));
  }, [settings]);
  useEffect(() => {
    localStorage.setItem("kck.voice.log", JSON.stringify(log.slice(0, 100)));
  }, [log]);

  // Load TTS voices
  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const load = () => setVoices(window.speechSynthesis.getVoices());
    load();
    window.speechSynthesis.onvoiceschanged = load;
  }, []);

  const speak = useMemo(() => (text: string) => {
    if (!settings.tts || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = settings.lang;
    u.rate = settings.rate;
    u.pitch = settings.pitch;
    const v = voices.find((vv) => vv.voiceURI === settings.voiceURI);
    if (v) u.voice = v;
    u.onstart = () => setSpeaking(true);
    u.onend = () => setSpeaking(false);
    u.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(u);
  }, [settings, voices]);

  function stopSpeaking() {
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }

  function addLog(entry: Omit<LogEntry, "id" | "ts">) {
    setLog((l) => [{ id: crypto.randomUUID(), ts: Date.now(), ...entry }, ...l].slice(0, 100));
  }

  /** Try to handle command locally; return reply if handled */
  function handleLocal(text: string): { reply: string; action?: string } | null {
    const command = resolveVoiceCommand(text);
    if (!command) return null;
    executeVoiceCommand(command);
    return { reply: command.reply, action: command.action };
  }

  async function askAI(text: string): Promise<string> {
    const history = log.slice(0, 6).reverse().flatMap((e) => [
      { role: "user", content: e.user },
      { role: "assistant", content: e.reply },
    ]);
    const { data: s } = await supabase.auth.getSession();
    const resp = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${s.session?.access_token}` },
      body: JSON.stringify({
        messages: [
          ...history,
          { role: "user", content: text },
        ],
      }),
    });
    if (!resp.ok || !resp.body) throw new Error("AI request failed");
    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = "", out = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf("\n")) !== -1) {
        let line = buf.slice(0, idx); buf = buf.slice(idx + 1);
        if (line.endsWith("\r")) line = line.slice(0, -1);
        if (!line.startsWith("data: ")) continue;
        const j = line.slice(6).trim();
        if (j === "[DONE]") return out;
        try {
          const d = JSON.parse(j).choices?.[0]?.delta?.content;
          if (d) out += d;
        } catch { buf = line + "\n" + buf; break; }
      }
    }
    return out;
  }

  async function processCommand(rawText: string) {
    let text = rawText.trim();
    if (!text) return;
    if (settings.wakeWord) {
      const m = text.toLowerCase().match(/(?:hey|ok)\s+kck[,!\s]*(.*)/);
      if (!m) return; // wake word not detected
      text = m[1].trim();
      if (!text) { speak("Yes?"); return; }
    }

    const local = handleLocal(text);
    if (local) {
      addLog({ user: text, reply: local.reply, action: local.action });
      speak(local.reply);
      return;
    }

    setThinking(true);
    try {
      const reply = await askAI(text);
      addLog({ user: text, reply });
      speak(reply);
    } catch (e: any) {
      const msg = "Sorry, I couldn't reach the assistant.";
      addLog({ user: text, reply: msg });
      toast.error(e.message || msg);
    } finally {
      setThinking(false);
    }
  }

  async function startListening() {
    const w = window as any;
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) { toast.error("Speech recognition not supported. Use Chrome or Edge."); return; }
    if (!window.isSecureContext) { toast.error("Voice requires HTTPS."); return; }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      s.getTracks().forEach((t) => t.stop());
    } catch (err: any) {
      toast.error(err?.name === "NotAllowedError" ? "Microphone permission denied." : "Microphone unavailable.");
      return;
    }
    const rec = new SR();
    rec.lang = settings.lang;
    rec.interimResults = true;
    rec.continuous = settings.continuous || settings.wakeWord;
    rec.onresult = (e: any) => {
      let finalText = "";
      let interimText = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) finalText += r[0].transcript;
        else interimText += r[0].transcript;
      }
      setInterim(interimText);
      if (finalText) {
        setInterim("");
        processCommand(finalText);
      }
    };
    rec.onerror = (e: any) => {
      if (e.error === "not-allowed") toast.error("Microphone blocked.");
      else if (e.error === "no-speech") { /* ignore */ }
      else if (e.error !== "aborted") toast.error(`Voice error: ${e.error}`);
    };
    rec.onend = () => {
      setListening(false);
      setInterim("");
      if (restartRef.current) {
        setTimeout(() => { try { rec.start(); setListening(true); } catch { /* */ } }, 300);
      }
    };
    try {
      rec.start();
      recRef.current = rec;
      restartRef.current = settings.continuous || settings.wakeWord;
      setListening(true);
    } catch {
      toast.error("Could not start voice input.");
    }
  }

  function stopListening() {
    restartRef.current = false;
    try { recRef.current?.stop(); } catch { /* */ }
    setListening(false);
  }

  function toggleListen() {
    if (listening) stopListening(); else startListening();
  }

  // Cleanup on unmount
  useEffect(() => () => { restartRef.current = false; try { recRef.current?.stop(); } catch { /* */ } window.speechSynthesis?.cancel(); }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/10 text-foreground">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
        <Link to="/chat" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20 ring-1 ring-primary/40">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          <span className="font-semibold">KCK Voice</span>
        </Link>
        <div className="flex items-center gap-2">
          <Link to="/chat" className="rounded-lg p-2 hover:bg-accent" title="Chat"><MessageSquare className="h-4 w-4" /></Link>
          <button onClick={() => setShowSettings((v) => !v)} className="rounded-lg p-2 hover:bg-accent" title="Settings"><Settings className="h-4 w-4" /></button>
          <button onClick={signOut} className="rounded-lg px-3 py-1.5 text-xs hover:bg-accent">Sign out</button>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-6 pb-16">
        {/* Orb */}
        <div className="flex flex-col items-center pt-8">
          <button
            onClick={toggleListen}
            className={cn(
              "group relative flex h-48 w-48 items-center justify-center rounded-full transition-transform",
              "bg-gradient-to-br from-primary/30 to-pink-500/20 ring-1 ring-primary/40 backdrop-blur",
              listening && "scale-105",
            )}
            aria-label={listening ? "Stop listening" : "Start listening"}
          >
            {/* pulse rings */}
            {listening && (
              <>
                <span className="absolute inset-0 animate-ping rounded-full bg-primary/30" />
                <span className="absolute -inset-4 animate-pulse rounded-full bg-primary/10" />
              </>
            )}
            <div className="relative flex h-32 w-32 items-center justify-center rounded-full bg-background/80 shadow-lg ring-1 ring-border">
              {listening ? <Mic className="h-12 w-12 text-primary" /> : <MicOff className="h-12 w-12 text-muted-foreground" />}
            </div>
          </button>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              {speaking ? "Speaking…" : thinking ? "Thinking…" : listening ? (settings.wakeWord ? "Listening for ‘Hey KCK’…" : "Listening…") : "Tap the mic to start"}
            </p>
            {interim && <p className="mt-2 text-base italic text-foreground/80">"{interim}"</p>}
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <Button variant={listening ? "secondary" : "default"} onClick={toggleListen}>
              {listening ? "Stop" : "Push to talk"}
            </Button>
            {speaking ? (
              <Button variant="outline" size="icon" onClick={stopSpeaking} title="Stop voice"><VolumeX className="h-4 w-4" /></Button>
            ) : (
              <Button variant="outline" size="icon" onClick={() => setSettings((s) => ({ ...s, tts: !s.tts }))} title="Toggle TTS">
                <Volume2 className={cn("h-4 w-4", !settings.tts && "opacity-40")} />
              </Button>
            )}
          </div>
        </div>

        {/* Shortcuts */}
        <section className="mt-10">
          <h2 className="mb-3 text-sm font-medium text-muted-foreground">Quick actions</h2>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-5">
            {SITE_SHORTCUTS.map((s) => (
              <button
                key={s.name}
                onClick={() => { window.open(s.url, "_blank", "noopener"); addLog({ user: `Open ${s.name}`, reply: `Opening ${s.name}.` }); }}
                className="rounded-xl border bg-card/60 px-3 py-3 text-sm backdrop-blur transition hover:bg-accent"
              >
                {s.name}
              </button>
            ))}
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            Try: "Open YouTube", "Search Google for Flutter tutorial", "Search YouTube for AI videos", "What's the time?"
          </p>
        </section>

        {/* Settings panel */}
        {showSettings && (
          <section className="mt-8 rounded-2xl border bg-card/60 p-5 backdrop-blur">
            <h2 className="mb-4 flex items-center gap-2 font-medium"><Settings className="h-4 w-4" /> Settings</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="text-sm">
                <span className="mb-1 block text-muted-foreground">Language</span>
                <select
                  className="w-full rounded-lg border bg-background px-2 py-2"
                  value={settings.lang}
                  onChange={(e) => setSettings((s) => ({ ...s, lang: e.target.value }))}
                >
                  {LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
                </select>
              </label>
              <label className="text-sm">
                <span className="mb-1 block text-muted-foreground">Voice</span>
                <select
                  className="w-full rounded-lg border bg-background px-2 py-2"
                  value={settings.voiceURI ?? ""}
                  onChange={(e) => setSettings((s) => ({ ...s, voiceURI: e.target.value || null }))}
                >
                  <option value="">Default</option>
                  {voices.map((v) => <option key={v.voiceURI} value={v.voiceURI}>{v.name} ({v.lang})</option>)}
                </select>
              </label>
              <label className="text-sm">
                <span className="mb-1 block text-muted-foreground">Rate: {settings.rate.toFixed(1)}</span>
                <input type="range" min={0.5} max={2} step={0.1} value={settings.rate}
                  onChange={(e) => setSettings((s) => ({ ...s, rate: +e.target.value }))} className="w-full" />
              </label>
              <label className="text-sm">
                <span className="mb-1 block text-muted-foreground">Pitch: {settings.pitch.toFixed(1)}</span>
                <input type="range" min={0} max={2} step={0.1} value={settings.pitch}
                  onChange={(e) => setSettings((s) => ({ ...s, pitch: +e.target.value }))} className="w-full" />
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={settings.wakeWord}
                  onChange={(e) => setSettings((s) => ({ ...s, wakeWord: e.target.checked }))} />
                Wake word ("Hey KCK")
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={settings.continuous}
                  onChange={(e) => setSettings((s) => ({ ...s, continuous: e.target.checked }))} />
                Continuous listening
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={settings.tts}
                  onChange={(e) => setSettings((s) => ({ ...s, tts: e.target.checked }))} />
                Speak responses
              </label>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">Settings saved locally on this device.</p>
          </section>
        )}

        {/* History */}
        <section className="mt-8">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-sm font-medium text-muted-foreground"><History className="h-4 w-4" /> Recent commands</h2>
            {log.length > 0 && (
              <button onClick={() => setLog([])} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive">
                <Trash2 className="h-3 w-3" /> Clear
              </button>
            )}
          </div>
          {log.length === 0 ? (
            <p className="rounded-xl border bg-card/40 p-4 text-sm text-muted-foreground">No commands yet. Tap the mic and try one.</p>
          ) : (
            <ul className="space-y-2">
              {log.map((e) => (
                <li key={e.id} className="rounded-xl border bg-card/60 p-3 text-sm backdrop-blur">
                  <div className="text-xs text-muted-foreground">{new Date(e.ts).toLocaleString()}</div>
                  <div className="mt-1"><span className="font-medium">You:</span> {e.user}</div>
                  <div className="mt-0.5 text-muted-foreground"><span className="font-medium text-foreground">KCK:</span> {e.reply}</div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <p className="mt-10 text-center text-xs text-muted-foreground">
          Signed in as {user?.email}. Voice features use your browser's Web Speech APIs.
        </p>
      </main>
    </div>
  );
}
